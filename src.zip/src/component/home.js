import axios from 'axios'
import React, { useEffect, useState } from 'react'


function Home() {
    const [weather, setWeather] = useState()
    const weatherKey ="fc93df6f8b664332812134242221907"
    const [cityName ,setCityName] = useState("chennai")
    const [contactValue, setContactValue] = useState()
    const [isLoading, setIsLoading] = useState(true);

  
  useEffect(()=>{
         axios.get(`http://api.weatherapi.com/v1/forecast.json?key=${weatherKey}&q=${cityName}&days=7`).then(response => {
            setWeather(response.data)
            console.log(response.data)
        }).finally(() => {
            setIsLoading(false);
        });
  },[cityName])
  const changing = (e) => {
    const {  value } = e.target;
    setContactValue( value )
    // console.log({...contactValue ,...inputFields});
  }
  const onSubmitHandler = (e) => {
    e.preventDefault()
    setCityName(contactValue)
    setContactValue("")
  }
//   console.log(cityName, "fufu");
//   console.log(weather,"data");
//   console.log(contactValue,"datainput");
    return (
        <div>
            <form className='search-input' onSubmit={onSubmitHandler}>
                <input type="text" onChange={changing} placeholder="search city" value={contactValue}/>
                <button type="submit">Search</button>
            </form>
            { isLoading ? "Loading...." : 
            <>
                <h1>weather api</h1>
                <h1>{weather?.location.name}</h1>
                <h4>{weather?.current.temp_c} / °c</h4>
                <img src={weather?.current.condition.icon}/>
                <h3>{weather?.current.condition?.text}</h3>
                <h3>{weather?.current.wind_kph} Km/h</h3>
                <h3>{weather?.current.humidity} % humidity</h3>
                <h3>{weather?.current.pressure_mb} mbar pressure</h3>
                </>
            }
            



            {/* {weather =="" ? 
            <div><h1>Is loading</h1></div>:
           <>
            <h1>weather api</h1>
            <h1>{weather.location.name}</h1>
            <h4>{weather.current.temp_c} / c</h4>
            
            <div>
            <img src={weather.current.condition.icon}/>
            <h3>{weather.current.condition.text}</h3>
            <div><p>{weather.current.wind_kph}Km/h</p></div>
           
            </div>
           </>

            } */}
            
          
            {/* <img src={weather.current.condition.icon}/> */}
        </div>
    )
}

export default Home
