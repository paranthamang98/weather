import logo from './logo.svg';
import './App.css';
import Home from './component/home';

function App() {
  return (
   <>
   <Home/>  
   </>
  );
}

export default App;
